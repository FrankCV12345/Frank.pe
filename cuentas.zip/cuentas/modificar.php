<?php 
$idcuenta = $_POST["IDCuenta"];
$fecha = $_POST["Fecha"];
$modigasto = $_POST["Modgasto"];
$modipago =  $_POST["ModPago"];

?>