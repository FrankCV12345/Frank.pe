<?php
$conexion=mysqli_connect("localhost","frankcam_prest","entrada38","frankcam_PrestamosBD");
/*if(! $conexion){
    echo"eror al conectar a la BD";
}
else{
    echo"Conectado a la BD";
}*/

?>
